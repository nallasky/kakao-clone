from flask import Flask, render_template, g
from flask_restful import Api
from flask_bcrypt import Bcrypt
from flask_cors import CORS
import sys

app = Flask(__name__, static_folder='./web/static', template_folder='./web/static')
api = Api(app)
bcrypt = Bcrypt(app)
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)


@app.route('/', defaults={'path': ''}, methods=['GET'])
def catch_all(path):
    g.jinja2_test = 'made by gtpark!'
    return render_template('index.html')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == 'test':
            app.debug = True
    app.run()
